const form = document.getElementById("emailForm");

form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const formData = new FormData(form); // handles file and text both

    try {
        const response = await fetch("/api/email/send", {
            method: "POST",
            body: formData, // do not set Content-Type manually
        });

        const result = await response.text();
        document.getElementById("response").innerText = result;
    } catch (error) {
        document.getElementById("response").innerText = "Error sending email.";
        console.error("Error:", error);
    }
});
